### 1.爬虫

~~~
vue->接口-》返回数据-》vue页面展示
html+css+js
xpath

加密-》加密js->js解密-》url地址接口

axios.post("234",data={'sdf':22,'token':'2'})

requests.post()

~~~

### 2.需求

~~~
写一个接口，从数据库读取数据，分页
jsonpath获取数据写入json文件



top250列表数据存入mysql
~~~

