### 1.用户模块

acl基于用户的模型

rbac基于角色权限管理

~~~
管理员用户表
id  name  mobile   roleid
1   张三             1
2   李四             1
3   小明             4
角色表
id   name  
1    内容审核员
2    营销人员
3    财务
4    客服
资源表
id  name            pid 
1   用户管理          0
2   普通用户管理      1
3   创作者管理         1
4   机构创建          1
5   内容管理          0
6    长视频           5

角色资源表
roleid  resid
1        2
1        3
2        2
2        6


vip表
id  name   条件
1   金牌    10
2   银牌     5
3   铜牌     1

用户表
id  用户名  头像  vip等级  vipid  

用户信息表
id userid 个性签名  身高 体重  


标签表
id  name

用户标签表
userid  tagid

创建者表
id   money

机构表
 单位名称   创作级别
 
主播表
id  总收益

视频分类表
id  name pid

频道表
id  名称

长视频表
id  发布人id  类型


帖子分类表

帖子表
id    分类id


订单表

订单详情表

充值记录表

提现记录表（充值50+收益50）

抽成比例表
min  max   比例
10   20    0.1
30   50    0.5

提现设置
1  10
2   5


工单分类表

工单表

通知公告表

页面表
 id   name    播放频率
 1    首页       1
 2    短视频页    3
 3    社区帖子    5


广告设置
id  名称   排序  admin_userid
1
2
3
4
5

广告页面表
页面id  广告id
2        1
2        5

       
配制表
1  3分钟
2  2

礼物表


外链表
id  名称  图片  地址  金额
京东   http://localhost:8080/index?code = 001
taobao   http://localhost:8080/index?code =002

外链记录表
id  来源 
1    001
     001
     002
     003
     

~~~

### 2.ER图

<img src="images/er.png">