### 1.创建表

~~~
create table user(
	id int primary key auto_increment,
	name varchar(30) not null default '',
	mobile varchar(11) not null default ''
);

insert into user(id,name) values(0,'张三');
update user set name='abc',mobile='123' where id=1
delete  from user  where id in (1,2,3)
~~~

~~~
1个大文件
5个小文件

文件名1.jpg
总数 5
当前片数  1
md5值 :
file

接口接收： 文件名创建夹

~~~

