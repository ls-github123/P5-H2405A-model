### 1.分页优化

~~~
1000
10  100
start = 1000

1000 - 990
990 -980
980 -970
970

//获取
select * from   where  limit 990,10 order by id desc
select * from tablename where id<=980 limit 0,10  order by id desc

1  2  3  4  5  6   7

key:page1   value: 10条数据转成字符串
key page2   value:  10条数据转成字符串
假如取第一页查询一共有多少条记录
3查询第二页

total - (page-1)*10


~~~

~~~
1 3 ....10  11  。。。。。20  

10000  1000
~~~

### 2.普通用户管理

~~~
需要表

用户表
用户信息表
标签表
用户标签表



from enum import Enum
class GenderEnum(Enum):
    MALE = '男'
    FEMALE = '女'


# 用户表
# id 用户名 手机号 余额 头像 vip等级 vipid 状态
class User(BaseModel):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    username = db.Column(db.String(64),nullable=False)
    mobile = db.Column(db.String(32),nullable=False)
    money = db.Column(db.Integer, default=0)
    url = db.Column(db.String(256),nullable=True)
    viplevel = db.Column(db.Integer,default=1)
    status = db.Column(db.Integer,default=0)
   


# 用户信息表
# id userid 个性签名 身高 体重
class Userinfo(BaseModel):
    __tablename__ = 'userinfo'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    userid = db.Column(db.Integer,db.ForeignKey('user.id'),nullable=False)
    signature = db.Column(db.String(256),nullable=True)
    height = db.Column(db.Integer)
    weight = db.Column(db.Integer)
    sex = db.Column(db.Enum(GenderEnum),nullable=False)


# 标签表
# id name
class Tags(BaseModel):
    __tablename__ = 'tag'
    name = db.Column(db.String(64),nullable=False)


# 用户标签表
# userid tagid
user_tags = db.Table(
    'user_tags',
    db.Column('userid',db.Integer,db.ForeignKey('user.id'),primary_key=True),
    db.Column('tagid',db.Integer,db.ForeignKey('tag.id'),primary_key=True)
)


~~~

