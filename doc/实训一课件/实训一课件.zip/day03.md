### 1.rbac

~~~
管理员用户表（admin_user）
角色表
id  name  pomition
1   管理     7
资源表
id  name  pid  pomition
1                0b1       1
                 0b10      2
                 0b100     4
                 0b1000    8
                           16
                           32
                           64
                           
位|添加权限
位&对比权限
^删除权限
                 
角色资源表




~~~

2.流程

角色管理

![image-20230331095415756](/Users/hanxiaobai/Library/Application Support/typora-user-images/image-20230331095415756.png)

添加用户，选择角色

![image-20230331095740644](/Users/hanxiaobai/Library/Application Support/typora-user-images/image-20230331095740644.png)

添加资源-》顶级资源

~~~

~~~



角色的资源配制