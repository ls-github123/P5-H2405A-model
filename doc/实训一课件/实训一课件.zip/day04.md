### 1.登录

~~~
用户管理-》添加-》姓名、性别、电话、角色


手机号、验证码-》验证码有效性验证-》去用户表中查询（admin_user）->id、roleid->通过roleid获取此用户对应的资源列表-》localStorage存，token,userid,权限列表
~~~

