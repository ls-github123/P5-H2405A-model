### 1.首页

~~~
推荐内容-》后台管理员首页推荐、排序，点击量，放到另外一张表中-》缓存-》查询redis，如果存在从redis取，如果不存在查询数据库-》setnx分布式锁

mes = r.get('homelist')
if mes:
	return 
else:
   if setnx('homelist',1,60):
     sql = "select * from limit 0,5"
     db.
     r.set()
     r.dele
   
   
 锁：threading.lock() 单服务器
 
     setnx 分步式环境
     
     
 mysql-》redis数据同步
 延时双删
 读-》先读取缓存，不存在，查询数据库
 写-》删除缓存，写数据库，删除缓存

~~~

