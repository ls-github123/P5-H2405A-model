### 1.登录

~~~
用户管理-》添加-》姓名、性别、电话、角色


手机号、验证码-》验证码有效性验证-》去用户表中查询（admin_user）->id、roleid->通过roleid获取此用户对应的资源列表-》localStorage存，token,userid,权限列表
~~~

### 2.位运算优化rabc

~~~
用户表
角色表
资源表
角色资源



位运算
用户表
角色表
id  name  pomition(int类型)
1.   客服   9

资源表
id  name     pid pomition
1   权限管理   0    
2   用户管理   1      1
3   资源管理   1      2
4   角色管理   1      4
5   订单管理   0       
6   添加订单   5      8



十进制
二进制

位|设置权限
对比& 
删除权限^


~~~

### 重构

~~~
1.添加资源接口
  #判断是菜单还是资源
  data = 
  if data['pid']>0:
  		maxres = Resource.objects.order_by("-pomition").limit(1)
  		number = maxres['pomition']*2
      Resource(name=name,pid=pid,pomition=number)
      
      
      
2.角色配制资源
  roleid=1
  reslist=[2,4]
  
  Roles.objects.filter(id=roleid).update({"pomition":0})
  
  
  pmes=0
  for  i in reslist:
      pmes = pmes | i
      
  Roles.objects.filter(id=roleid).update({"pomition":pmes})
  
  
  
 3.获取角色对应的资源
resall = Roles.objects.filter(id=roleid).first()
res = Resource.objects.filter(pid__get=0).all()
list =[]
for i in res:
   if resall & i:
      list.append(i)
    
     
~~~

vant网址

https://vant-contrib.gitee.io/vant/v2/#/zh-CN/submit-bar

#### Vue 2 项目，安装 Vant 2

~~~
cnpm i vant@latest-v2 -S
~~~

### 在main.js中导入

~~~
import Vue from 'vue';
import Vant from 'vant';
import 'vant/lib/index.css';

Vue.use(Vant);
~~~

### 实名认证

~~~
登录成功后-》
头像  名称
可用余额 100
充值
提现
实名认证
~~~

<img src="images/12.png">

~~~
调用百度文字识别
个人:2qps
企业：10qps
~~~

