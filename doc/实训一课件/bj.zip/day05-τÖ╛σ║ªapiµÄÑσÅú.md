### 1.三方登录

~~~
1.微博平台配制
2.在登录页面加一个图标，调用接口获取微博url
3.
~~~

### 2.百度qps限制

~~~
个人2qps
企业10qps
每秒实证认证的人是10个
队列
图片的url,将url放入队列
定时任务每秒执行一次：从队列中取出2条数据，调用百度接口，返回数据放到redis,key 图片url value:{"name":'34','code':'234'}

vue setInteval每秒请求一个接口：携带图片地址这个参数，通过这个参数去redis中查询，如果有数据直接返回，clearInterval

websocket

百度企业10qps，20qps
队列：
1.图片上传到云服务器，调用接口，将图片地址写入队列中
2.定时任务django-celery每隔一秒执行一次，从获取中获取10条，发送请求，获取到结果，把结果存在redis
3.setInterval每隔一秒去获取信息，拿到数据clearInterval
~~~

### 2.celery使用

1.安装

~~~
pip uninstall celery
pip intall celery
~~~

2.在settings中配制

~~~python
# Celery配置
# from kombu import Exchange, Queue
# 设置任务接受的类型，默认是{'json'}
CELERY_ACCEPT_CONTENT = ['application/json']
# 设置task任务序列列化为json
CELERY_TASK_SERIALIZER = 'json'
# 请任务接受后存储时的类型
CELERY_RESULT_SERIALIZER = 'json'
# 时间格式化为中国时间
CELERY_TIMEZONE = 'Asia/Shanghai'
# 是否使用UTC时间
CELERY_ENABLE_UTC = False
# 指定borker为redis 如果指定rabbitmq CELERY_BROKER_URL = 'amqp://guest:guest@localhost:5672//'
CELERY_BROKER_URL = 'redis://127.0.0.1:6379/0'
# 指定存储结果的地方，支持使用rpc、数据库、redis等等，具体可参考文档 # CELERY_RESULT_BACKEND = 'db+mysql://scott:tiger@localhost/foo' # mysql 作为后端数据库
CELERY_RESULT_BACKEND = 'redis://127.0.0.1:6379/1'
# 设置任务过期时间 默认是一天，为None或0 表示永不过期
CELERY_TASK_RESULT_EXPIRES = 60 * 60 * 24
# 设置worker并发数，默认是cpu核心数
# CELERYD_CONCURRENCY = 12
# 设置每个worker最大任务数
CELERYD_MAX_TASKS_PER_CHILD = 100


# 指定任务的位置
CELERY_IMPORTS = (
    'base.tasks',
)
# 使用beat启动Celery定时任务
# schedule时间的具体设定参考：https://docs.celeryproject.org/en/stable/userguide/periodic-tasks.html
CELERYBEAT_SCHEDULE = {
    'add-every-10-seconds': {
        'task': 'base.tasks.cheduler_task',
        'schedule': 10,
        'args': ('hello', )
    },
}

~~~

在settings同级目录下新celery.py

~~~python
# from __future__ import absolute_import, unicode_literals
import os
from celery import Celery, platforms



os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'videoadmin.settings')
app = Celery('videoadmin',broker='redis://127.0.0.1:6379/1',  # 任务存放的地方 
             backend='redis://127.0.0.1:6379/15')

app.config_from_object('django.conf:settings')

app.autodiscover_tasks()

platforms.C_FORCE_ROOT = True




# @app.task(bind=True)
# def debug_task(self):
#     print('Request: {0!r}'.format(self.request))

~~~

在settings同级目录__init__.py中

~~~python
# from __future__ import absolute_import, unicode_literals

# This will make sure the app is always imported when
# Django starts so that shared_task will use this app.
from .celery import app as celery_app

__all__ = ('celery_app',)

~~~

在项目目录下创建base文件夹，在base下新建tasks.py文件

~~~
# from __future__ import absolute_import, unicode_literals
from celery import shared_task
import time

@shared_task
def cheduler_task(name):
   end = int(time.time())-600
   olist = r.sorted_times(key,0,end)
   for i in olist:
      res = alipay.query_pay(i.decode())
      requests
      content = res.text
      #更新订单更新用户余额

~~~

启动任务

~~~
启动worker
celery -A job.celery_job  worker -l info

windows下启动 celery -A videoadmin  worker -l info -P eventlet 
启动定时beat
celery -A videoadmin beat -l info

~~~

