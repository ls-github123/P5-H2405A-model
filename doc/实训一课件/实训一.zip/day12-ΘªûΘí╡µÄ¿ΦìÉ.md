### 1.协同过滤算法

~~~
1.基于用户的
   （1）统计用户群体，相当于给用户分类
   （2）当A购买一个物品时，通过这个物品查询和他一类的这些人是否买过，如果没有就推荐
   
2.基于物品的
    经常看哪类，关注哪类，推荐哪类
~~~

### 2.代码实现

~~~
新建一张浏览记录表
id userid  videoid  number
1   1       1         10
2   1       5          5
5   4       5         7
3   2       1         7
4   3       8         2



~~~



~~~python
def recommend_movies(request):
    # 获取当前用户的所有购买的商品
    user_ratings = OrdersDetils.objects.filter(userid=1)

    # 计算当前用户与其他用户的相似度
    similarity_scores = {'2':{'score':1,'count':9}}
    #遍历此用户订单
    for rating in user_ratings:
        #查询和此用户购买商品相同的人
        for r in OrdersDetils.objects.filter(vedioid=rating.vedioid).exclude(userid=1):
            if r.userid not in similarity_scores:
                similarity_scores[r.userid] = {'score': 0, 'count': 0}
            similarity_scores[r.userid]['score'] += abs(r.number - rating.number)
            similarity_scores[r.userid]['count'] += 1
    for user, score_count in similarity_scores.items():
        similarity_scores[user]['score'] = score_count['score'] / score_count['count'] if score_count['count'] > 0 else 0

    # 按相似度排序，选出与当前用户相似度最高的前 n 个用户
    similar_users = sorted(similarity_scores.items(), key=lambda x: x[1]['score'])[:10]

    # 找出这些用户买过但是我没买过的商品进行推荐
    recommended_movies = []
    for user, score_count in similar_users:
        for rating in OrderDetails.objects.filter(userid=user):
            if not OrderDetails.objects.filter(vedioid=rating.vedioid, userid=1).exists():
                vedios = Publish0.objects.filter(id=rating.vedioid).first()
                recommended_movies.append({"vedioid":rating.vedioid,'tcount':rating.tcount,'name':vedios.title})
                

    # 按平均评分排序，选出前 n 个商品作为推荐结果
    recommended_movies = sorted(recommended_movies, key=lambda x: x['tcount'], reverse=True)[:10]

    return JsonResponse({"code":200,'list':recommended_movies})
~~~

实现

~~~
1.查询浏览记录表，大于3条，采用协同过滤算法中的基于用户的推荐获取视频列表
2.如果不存在
select * from publish0 limit 0,2 order by add_time desc union all select * from publish1 limit 0,2 order by add_time desc union select * from publish2 limit 0,2 order by add_time desc;


视频1
视频2
视频3

3.点击视频1，dialog弹出框，播放视频。写入到浏览记录表


您好，我叫毛敬龙，大学学的是计算机科学与技术。有3年的工作经验，一直做的都是python web开发，涉及到的项目有电商平台、医疗平台、在线教育平台等多种项目类型。现在开发市场不好，大公司裁员。我想找一个稳定的工作，了解了数据标注和数据审核岗位觉得不错。我对咱们这个岗位非常感兴趣，也打算长期稳定。我的优点就是踏实、认真、能坚持。不喜欢老换工作。我也能适应加班什么的高强度工作，多锻炼自己的各方面能力。我也在网上了解了一下数据审核，基本的工作内容是辅助客户完善需要提交的资料，解决遇到的问题。以及对用户提交的信息进行审核，比如一些敏感词汇或者违法的都要过滤。对于录音，录像，照片等，根据这些内容和电子表格的结果进行比对，于不合格的样本检查出来的错误要进行改正和标注。并且不能有太多漏查，误判的地方。按时按量的审核样本数量，保证合理的工作效率和进度。我相信我能胜任这份工作，并且会努力做好。我的介绍完了。谢谢

~~~

