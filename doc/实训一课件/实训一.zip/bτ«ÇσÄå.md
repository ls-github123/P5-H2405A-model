### 1.jwt用户认证模块

~~~
客户端自认证，节约了服务器资源。
session的工作机制   jsessionid->服务器生成一个文件,session实现单点登录
jwt  加密 base64(头部).bash64(载和).hash256(base64(头部).bash64(载和),'')
vue interceptors拦截器
装饰器方式
中间件
~~~

### 2.rbac实现基于角色的权限管理

~~~
acl
rbac
abac

位运算
| 
&
^
~~~

### 3.百度实名认证

~~~

~~~

### 4.发布模块大文件上传、分表

~~~
10  5  3
~~~



