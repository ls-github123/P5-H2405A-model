### 1.充值模块

~~~
支付宝配制-》页面-》选择支付方式（单选、默认选中支付宝）、输入金额-》提交-》写入充值记录表（订单号、userid、create_time、money,pay_type,status,transaction_no）->获取支付宝链接（加入队列订单号）-》返回给页面-》点击跳转到支付宝平台-》登录、输入密码、支付-》支付成功后回调-》验签通过更新充值记录表中的状态、更新用户表中的总金额（事务处理）

支付成功回调失败：
celery定时任务，延时队列。
定时任务：从队列中取出半小时前的数据，调用支付宝查询接口，进行查询，更新充值记录表中的状态、更新用户表中的总金额（事务处理）

~~~

~~~
 from django.db import transaction
# 创建保存点
save_id = transaction.savepoint()  
# 回滚到保存点
transaction.savepoint_rollback(save_id)
# 提交从保存点到当前状态的所有数据库事务操作
transaction.savepoint_commit(save_id)
 
 with transaction.atomic():
   # 创建事务保存点
   save_id = transaction.savepoint()  # 记录了当前数据库的状态
   try:
     #更新充值订单表
     #更新用户
     transaction.savepoint_commit(save_id)
   except:
     transaction.savepoint_rollback(save_id)
     
~~~

