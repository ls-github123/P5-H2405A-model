### 1.rbac

~~~
管理员用户表（admin_user）
角色表
id  name  pomition
1   管理     7
资源表
id  name  pid  pomition
1                0b1       1
                 0b10      2
                 0b100     4
                 0b1000    8
                           16
                           32
                           64
                           
位|添加权限
位&对比权限
^删除权限
                 
角色资源表




~~~

2.流程

角色管理

![image-20230331095415756](/Users/hanxiaobai/Library/Application Support/typora-user-images/image-20230331095415756.png)

添加用户，选择角色

![image-20230331095740644](/Users/hanxiaobai/Library/Application Support/typora-user-images/image-20230331095740644.png)



~~~
角色：销售   4个资源  用户管理、角色管理、资源管理、财务管理

添加一个用户小明，小明属于销售角色
小明登录：
权限管理
   用户管理
   角色管理
   资源管理
财务模块
   财务管理
   
   
   select res.id,res.name,pres.id,pres.name from resources_roles as rr inner join resources as res on rr.resource_id=res.id  left join resources as pres on pres.id=res.pid where rr.roles_id=1;
~~~

~~~
def getmes():
   #获取主表数据，生成id
   getdetail(id)
   
   
   
def getdetil(id):
   #查询详情表
   detail = Detail.objects.all()
   host="http://w33243.com/detail/"
   for i in deatil:
       url = host+i.id
       try:
         res = request.get(url,headers={"":""})
         tt = json.loads(res.text)
       except:
          redis.lpush('asdf',i)
 
 def detail():
    id = redis.rpop('asdf')
  
  	res = request.get(url,headers={"":""})
  	tt = json.loads(res.text)
     
~~~



角色的资源配制

资源互斥

~~~
互斥表
res1  res2
 1      2
 3      1
 5      6
 
 
角色配制资源
1，3，5
#查询此角色继承的资源 24
#合并资源 list= 2，3，5
#查询互斥表
for i in list:
    res = mutext.objects.filter(res1=i).first()
    if res.res2 in list:
       return ‘存在互斥不能配制’



 

~~~

