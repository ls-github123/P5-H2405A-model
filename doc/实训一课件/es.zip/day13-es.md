### 1.倒排索引

<img src="/Users/hanxiaobai/Downloads/python/p8/课件/newp8/p9/images/3.png">



~~~
goods
id  title
title like '% %'
goods
title



倒排索引
id  name  content    url
1   新闻    苦柑新闻   
2   建国    苦柑建国新闻  

select * from goods where name like '%asfd%'



新闻
select id,title,url from publish0 where title like '%新闻%' or content like '%新闻%'

洗衣机降价，299快来抢购洗衣机
Jieba分词或者ik分词将一段文字分隔成词组
洗衣机 -》[{文档id 位置 次数   1001  0，8   2},{}]
降价
299
快来
抢购




倒排索引
我是中国人   我喜欢呆在中国，茜顶戴茜顶起顶起权志龙顶我起村村   文档1，3次，【0，0，10】
我叫小红   asdf顶起
通过ik或者jebia分词将一段话变成多个分词，将分词做为key,文档id,出现的位置，出现的次数作为value存储在hashmap中
我   是   中国 人  我  喜欢   呆在   中国
我  叫   小红

我
{‘我’:[{文档1，3}，[文档2，2，]]}


什么是倒排索引
搜索的核心需求是全文检索，全文检索简单来说就是要在大量文档中找到包含某个单词出现的位置，在传统关系型数据库中，数据检索只能通过 like 来实现。

例如需要在酒店数据中查询名称包含公寓的酒店，需要通过如下 sql 实现：

select * from hotel_table where hotel_name like '%公寓%';
这种实现方式实际会存在很多问题：

无法使用数据库索引，需要全表扫描，性能差
搜索效果差，只能首尾位模糊匹配，无法实现复杂的搜索需求
无法得到文档与搜索条件的相关性
搜索的核心目标实际上是保证搜索的效果和性能，为了高效的实现全文检索，我们可以通过倒排索引来解决。

倒排索引是区别于正排索引的概念：

正排索引：是以文档对象的唯一 ID 作为索引，以文档内容作为记录。
倒排索引：Inverted index，指的是将文档内容中的单词作为索引，将包含该词的文档 ID 作为记录。



倒排索引
title   001华为手机    002小米手机
ik  jieba
华为  手机
手机 =》{001（出现次数，出现位置），002}
~~~

<img src="/Users/hanxiaobai/Downloads/python/p8/课件/newp8/p9/images/1.png">

倒排索引的结构
根据倒排索引的概念，我们可以用一个 Map来简单描述这个结构。这个 Map 的 Key 的即是分词后的单词，这里的单词称为 Term，这一系列的 Term 组成了倒排索引的第一个部分 —— Term Dictionary (索引表，可简称为 Dictionary)。

倒排索引的另一部分为 Postings List（记录表），也对应上述 Map 结构的 Value 部分集合。

记录表由所有的 Term 对应的数据（Postings） 组成，它不仅仅为文档 id 信息，可能包含以下信息：

文档 id（DocId, Document Id），包含单词的所有文档唯一 id，用于去正排索引中查询原始数据。
词频（TF，Term Frequency），记录 Term 在每篇文档中出现的次数，用于后续相关性算分。
位置（Position），记录 Term 在每篇文档中的分词位置（多个），用于做词语搜索（Phrase Query）。
偏移（Offset），记录 Term 在每篇文档的开始和结束位置，用于高亮显示等。
<img src="/Users/hanxiaobai/Downloads/python/p8/课件/newp8/p9/images/2.png">

### 2.docker

~~~
linux两个版本,centos7  ubuto
虚拟机： windows centos7，

仓库、镜像、容器
从中央仓库拉取镜像，通过镜像可以创建容器
~~~

### 3.docker安装

~~~
#升级所有包同时也升级软件和系统内核；
yum -y update 
#只升级所有包，不升级软件和系统内核
yum -y upgrade

#删除自带的docker
yum remove docker  docker-common docker-selinux docker-engine

1.安装需要的软件包， yum-util 提供yum-config-manager功能，另两个是devicemapper驱动依赖
yum install -y yum-utils device-mapper-persistent-data lvm2

设置一个yum源，下面两个都可用,选择一个
yum-config-manager --add-repo http://download.docker.com/linux/centos/docker-ce.repo（中央仓库）
 
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo（阿里仓库）

#查看可用版本
yum list docker-ce --showduplicates | sort -r
#安装docker
yum -y install docker-ce-18.03.1.ce

#设置开机启动
systemctl start docker
systemctl enable docker

xshell
~~~

### 4.docker搭建es

~~~
docker pull elasticsearch:7.7.0
~~~

~~~
docker run --name elasticsearch -d -e ES_JAVA_OPTS="-Xms512m -Xmx512m" -e "discovery.type=single-node" -p 9200:9200 -p 9300:9300 elasticsearch:7.7.0
~~~

### 3.es基础语法

http://182.92.237.172:9200/shopping

创建索引  地址加索引名

~~~
发送put请求： http://localhost:9200/shopping
~~~

查看索引

~~~
发送get请求： http://localhost:9200/shopping

查看所有索引
http://localhost:9200/_cat/indices?v
~~~

删除索引

~~~
发送delete请求  http://localhost:9200/shopping
~~~

添加数据

~~~
发送post请求 http://localhost:9200/shopping/_doc

{
	"name":"张三",
	"age":10,
	"category":1,
	"status":1,
	"online":2
}

幂等性操作  
添加时添加id  http://localhost:9200/shopping/_doc/1001
~~~

查询数据

~~~
发送get请求  http://localhost:9200/shopping/_doc/1002
查询全部  http://localhost:9200/shopping/_search
~~~

修改

~~~
完全覆盖 
发送put请求 http://localhost:9200/shopping/_doc/1001

修改某个属性
发送post请求 http://localhost:9200/shopping/_update/1001
{
	"name":"张三22"
}

~~~

删除

~~~
完全覆盖 
发送delete请求 http://localhost:9200/shopping/_doc/1001
~~~

条件查询

~~~json
get http://localhost:9200/shopping/_search

{
	"query":{
		"match":{"category":1}
	}
}

查询所有数据
{
	"query":{
		"match_all":{}
	}
}
~~~

分页查询

~~~
{
	"query":{
		"match_all":{}
	},
	"from":0,
	"size":2
}


指定字段
{
	"query":{
		"match_all":{}
	},
	"from":0,
	"size":2,
	"_source":["name"]
}
~~~

排序

~~~
{
	"query":{
		"match_all":{}
	},
	"from":0,
	"size":2,
	"_source":["name","age"],
	"sort":{
		"id":{
			"order":"desc"
		}
	}
}
~~~



多条件查询

And

~~~
{
	"query":{
		"bool":{
			"must":[
				{"match":{"age":10}},
				{"match":{"name":"张三"}}
				]
		}
	},
	"from":0,
	"size":2,
	"_source":["name","age"],
	"sort":{
		"age":{
			"order":"desc"
		}
	}
}

select * from users where age=10 and name="张三"
~~~

or

~~~
{
	"query":{
		"bool":{
			"should":[
				{"match":{"age":10}},
				{"match":{"name":"张三"}}
				]
		}
	},
	"from":0,
	"size":2,
	"_source":["name","age"],
	"sort":{
		"age":{
			"order":"desc"
		}
	}
}

select * from users where age=10 or name="张三"
~~~

范围查询

~~~
{
	"query":{
		"bool":{
			"should":[
				{"match":{"age":10}},
				{"match":{"name":"张三"}}
			],
			"filter":{
				"range":{
					"age":{"gt":3}
				}
			}
		}
	},
	"from":0,
	"size":2,
	"_source":["name","age"],
	"sort":{
		"age":{
			"order":"desc"
		}
	}
}


es支持常用的语法，通过from size进行分页查询，match条件查询，_source指定返回字段，sort排序，range进行区间查询,must并且查询，should进行或查询
~~~

```
# 获取数据量
es.count(index``=``"my_index"``,doc_type``=``"test_type"``)
```

例子

~~~
使用es查询商品信息
1.先mysql中的数据加载到es中,第一次全量式同步，后面增量式同步
2.实例化Elasticsearch类
3.es.index创建索引，把记录添加到es中
4.用es._search从查询数据
~~~



~~~
"""
es 引擎相关
"""
 
from elasticsearch import Elasticsearch
# 创建es 实例
es = Elasticsearch("http://localhost:9200/")
 
~~~

同步数据

~~~
from elasticsearch import Elasticsearch
import traceback

@user_blue.route("/esinsert")
def insert_data_to_es():
    es = Elasticsearch("http://localhost:9200/")
    # 清空数据
    # es.indices.delete(index='user')
    try:
        i = -1
        for row in get_db_data():
            print(row)
            print(row[1], row[2])
            i += 1
            # index就是对应的一张表 eg.对应的就是course表
            es.index(index='user1', body={
                'id': i,
                'table_name': 'user1',
                'mobile': row[1],
                'roleid': row[2],
            })
        print("###")
    except:
        print("&&&")
        error = traceback.format_exc()
        print("Error: unable to fecth data", error)
        pass
    return 'ok'



~~~

使用

~~~
from util.myes import ES
@user_blue.route("/find")
def find():
     es = ES(index_name='user1')
     result = es._search("18210203878", fields=['mobile'])
     print(result)
     return 'ok'
~~~

~~~
create table test(
	id int primary key auto_increment,
	name varchar(30),
	age  int,
	descr varchar(200)
);

insert into test values(0,"张三",10,"茜茜遥遥爱你的的伯伯"),(0,"李四",1,"茜茜遥遥爱你的的伯伯33333"),(0,"张三123",50,"茜茜遥遥爱你的的伯伯111"),(0,"张三22",30,"茜茜遥遥爱你的的伯伯2222");
~~~

~~~
from elasticsearch import Elasticsearch

es = Elasticsearch(hosts="http://127.0.0.1:9200/")

@goods_blue.route("/addesformysql")
def addesformysql():
    sql ="select * from test"
    res = db.findAll(sql)
    for i in res:
        es.index(index='test', body={
                'id': i['id'],
                'table_name': 'test',
                'name': i['name'],
                'age': i['age'],
            })
@goods_blue.route("/findes")
def findes():
    dsl={
        "query":{
            "match":{"name":"张三"}
        }

    }
    res = es.search(index="test", body=dsl)
    print(res['hits']['hits'])
    return 'ok'


作业：
写一张表，包含姓名，性别，年龄？加10条不同年龄段不同性别的数据

同步数据到es,每个组命名user1代表1组

1.查询性别为“男”的所有记录
2.查询年龄在20-30之间的，包含20，30
3.查询名字中包含‘小’的记录，并分页显示，每页面显示2条记录，根据id倒序排列

~~~

<img src="/Users/hanxiaobai/Downloads/python/p8/课件/newp8/p9/images/8.png">

~~~
# 查询名字中包含‘小’的记录，并分页显示，每页面显示2条记录，根据id倒序排列
@goods_blue.route("/findes")
def findes():
    page = request.args.get("page")
    pagesize = 2
    start = (int(page)-1)*pagesize
    dsl={
	"query":{
		"match":{"name":"张三"}
	},
	"from":start,
	"size":pagesize,
	"sort":{
		"id":{
			"order":"desc"
		}
	}
}
    #查询共有多少条记录的条件
    dsl1={
	"query":{
		"match":{"name":"张三"}
	}}
    res = es.search(index="test", body=dsl)
    count = es.count(index="test",body=dsl1)
    print(count['count'])
    print(res['hits']['hits'])
    return 'ok'

~~~

~~~python

@u_blue.route("/find")
def find():
    page = request.args.get("page")
    pagesize=1
    start =(int(page)-1)*pagesize
    es = Elasticsearch("http://localhost:9200/")
    sortid = request.args.get("sortid")
    type1 = request.args.get("type")
    tagid = request.args.get("tagid")
    online = request.args.get("online")
    str = '"match_all":{}'
    flag = False
    ss = '"bool":{"must":[{"match":{"'
    if type1:
        flag=True
        ss=ss+'type":'+type1+'}}'
    if online:
        if flag == True:
            ss=ss+',{"match":{"online":'+online+'}}'
        else:
            flag=True
            ss=ss+'online":'+online+'}}'
    if tagid:
        if flag == True:
            ss=ss+',{"match":{"tagid":'+tagid+'}}'
        else:
            flag=True
            ss=ss+'tagid":'+tagid+'}}'

    if flag == True:
        str = ss+']}'
    
    if sortid:
        sort = '"sort":{"id":{"order":"desc"}}'
        dsl = '{'+'"query":{'+str+'},"from":'+str(start)+',"size":'+str(pagesize)+','+sort+'}'
    else:
        dsl = '{'+'"query":{'+str+'},"from":'+start+',"size":20}'

    match_data = es.search(index="courses", body=dsl)
    results=[]
    for hit in match_data['hits']['hits']:
        results.append(hit['_source'])
    return jsonify({"res":results})
~~~

~~~python
from elasticsearch import Elasticsearch
import traceback
@u_blue.route("/estest") 
def estest():
    es = Elasticsearch("http://localhost:9200/")
    # 清空数据
    es.indices.delete(index='courses')
    try:
        sql = "select c.*,cl.labelid from courses as c left join courses_label as cl on c.id=cl.coursesid"
        i = -1
        res = db.findAll(sql)
        for row in res:
            i += 1
            # index就是对应的一张表 eg.对应的就是course表
            es.index(index='courses', body={
                'id': i,
                'table_name': 'courses',
                'name': row['name'],
                'pid': row['classify'],
                'type': row['type'],
                'img': row['img'],
                'labelid': row['labelid'],
                'addtime': row['add_time'],
                "online":row['online']
            })
        print("###")
    except:
        print("&&&")
        error = traceback.format_exc()
        print("Error: unable to fecth data", error)
        pass
    return 'ok'
~~~

~~~
insert into userinfo values(0,'2021-10-10 10:10:10','2021-11-10 10:10:10',0,'1005','lkasf','i.jpg','1123245',2,1,10,1);
insert into userinfo values(0,'2022-10-10 10:10:10','2022-10-11 10:10:10',0,'1006','gas324','i.jpg','1223535345',2,1,0,1);
~~~

