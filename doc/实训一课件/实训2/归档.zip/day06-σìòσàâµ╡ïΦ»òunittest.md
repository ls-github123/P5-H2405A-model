# 第十单元

---

[TOC]





## 10.1 测试用例

### 10.1.1 需求分析★★★★★

| 需求编号 | 模块         | 功能     | 需求分析                                                     |
| -------- | ------------ | -------- | ------------------------------------------------------------ |
| 1        | 注册模块     | 注册     | 账号长度必须为6-15位,必须包含大写字母、小写字母、数字。<br>密码长度必须为8-20位,必须包含字母、数字。<br>两次输入密码必须一致。<br>禁止复制粘贴。<br>下拉框必须要有默认选中项。 |
| 2        | 登录模块     | 登录     | 正确的账号密码(测试),登录成功。<br>手机号登录。<br>三方登录。 |
| 3        | 上传资质模块 | 上传资质 | 用户必须为登录状态(token的校验)。<br>上传资质(图片)最大为2x1024KB。 |
| 4        | 上传物料模块 | 上传物料 | 用户必须为登录状态(token的校验)。<br>单次上传资质(图片、视频、音频等)最大为8x1024KB。 |

## 10.1.2 需求评审★★★★★

通过,无异议

## 10.1.3 用例分析★★★★★

### 注册

![](/Users/hanxiaobai/Downloads/python/实训一/讲义新/day11/广告竞价平台课件/images/c10.png)

### 登录(账密)

![](/Users/hanxiaobai/Downloads/python/实训一/讲义新/day11/广告竞价平台课件/images/c10_1.png)

### 上传资质

![](/Users/hanxiaobai/Downloads/python/实训一/讲义新/day11/广告竞价平台课件/images/c10_3.png)

### 上传物料

![](/Users/hanxiaobai/Downloads/python/实训一/讲义新/day11/广告竞价平台课件/images/c10_4.png)

## 10.1.4 用例评审★★★★★

###通过,无异议


## 10.1.5 用例编写★★★★★

### 等价类划分

#### 注册

有效等价类：
&emsp;&emsp;账号长度必须在6-15位范围内,必须包含大写字母、小写字母、数字。
&emsp;&emsp;密码长度必须在8-20位范围内,必须包含字母、数字、特殊字符。
&emsp;&emsp;两次输入密码必须一致。
无效等价类：
&emsp;&emsp;账号长度在6-15位范围外,其中包含特殊字符。
&emsp;&emsp;密码长度在8-20位范围外,其中包含特殊字符。
&emsp;&emsp;两次输入密码不一致。


#### 登录(账密)

有效等价类：
&emsp;&emsp;账号长度必须在6-15位范围内,必须包含大写字母、小写字母、数字。
&emsp;&emsp;密码长度必须在8-20位范围内,必须包含字母、数字、特殊字符。
无效等价类：
&emsp;&emsp;账号长度在6-15位范围外,其中包含特殊字符。
&emsp;&emsp;密码长度在6-15位范围外,其中包含特殊字符。


### 上传资质

有效等价类：
&emsp;&emsp;用户必须为登录状态。
&emsp;&emsp;资质(图片)大小在1-2x1024kb范围内。
无效等价类：
&emsp;&emsp;用户为非登录状态。
&emsp;&emsp;资质(图片)大小在1-2x1024kb范围外。 (取0.9、2049kb)

### 上传物料

有效等价类：
&emsp;&emsp;用户必须为登录状态。
&emsp;&emsp;资质(图片)大小在1-8x1024kb范围内。
无效等价类：
&emsp;&emsp;用户为非登录状态。
&emsp;&emsp;资质(图片)大小在1-8x1024kb范围外。 (取0.9、8193kb)

## 10.2 自动化测试

## 10.2.1 Unittest使用★★★★★

###代码示例

```
# 调用测试类
class TestCount(unittest.TestCase):

    # 初始化方法
    def setUp(self):

        print("开始测试")

    # 编写测试用例
    def test_add(self):

        # 实例化对象
        self.Count = Count(6,3)

        # 断言
        self.assertEqual(self.Count.add(),9)
    
    # 析构方法
    def tearDown(self):

        print("结束测试")
    

 if __name__=="__main__":

     # 构造测试集
     suite = unittest.TestSuite()
     suite.addTest(TestCount("test_add"))


     # 进行测试
     runner = unittest.TextTestRunner()
     runner.run(suite)
```

## 10.2.2 单元测试★★★★★

```
import unittest

from HTMLTestRunner import HTMLTestRunner

import requests

class TestRegisterLogin(unittest.TestCase):

    def setUp(self):
        pass

    # 编写注册测试用例(账号、密码合法)
    def register(self):

        res = requests.post("http://localhost:8000/userinfo/",data={"username":"Admin1","password":"zhang123","type":1})

        res=res.json()["meg"]

        # 断言
        self.assertEqual(res,"注册成功")

    # 编写注册测试用例(账号不合法)
    def register_username(self):

        res = requests.post("http://localhost:8000/userinfo/",data={"username":"admin1","password":"zhang123","type":1})

        res=res.json()["meg"]

        # 断言
        self.assertEqual(res,"账号不合法")

    # 编写注册测试用例(密码不合法)
    def register_password(self):

        res = requests.post("http://localhost:8000/userinfo/",data={"username":"Admin1","password":"11","type":1})

        res=res.json()["meg"]

        # 断言
        self.assertEqual(res,"密码不合法")

    # 编写登录测试用例(账号、密码合法)
    def login(self):

        res = requests.get("http://localhost:8000/userinfo/",params={"username":"Admin1","password":"zhang123","type":1})
        
        res=res.json()["meg"]
        
        # 断言
        self.assertEqual(res,"登录成功")

    # 编写登录测试用例(账号不合法/错误)
    def login_username(self):

        res = requests.get("http://localhost:8000/userinfo/",params={"username":"admim1","password":"z123456","type":1})
        
        res=res.json()["meg"]
        
        # 断言
        self.assertEqual(res,"登录失败,用户名或密码错误")

    # 编写登录测试用例(密码不合法/错误)
    def login_password(self):

        res = requests.get("http://localhost:8000/userinfo/",params={"username":"admim1","password":"z123456","type":1})
        
        res=res.json()["meg"]
        
        # 断言
        self.assertEqual(res,"登录失败,用户名或密码错误")

    def tearDown(self) -> None:
        pass

if __name__ =='__main__':
   
    # 构造测试集
    suite = unittest.TestSuite()

    suite.addTests([TestRegisterLogin('register'),

                    TestRegisterLogin('register_username'),

                    TestRegisterLogin('register_password'),

                    TestRegisterLogin('login'),

                    TestRegisterLogin('login_username'),

                    TestRegisterLogin('login_password')

                    ])

    
    #使用testrunner生成测试报告
    runner = HTMLTestRunner(log=True,output="report",title="test report",report_name="report",open_in_browser=True
    ,description="测试")
    
    runner.run(suite)
```

## 10.2.3 异步方式★★★★★

请求url:/userinfo/
请求方式:POST
公共参数:

| 参数名称 | 参数类型 | 是否必填 |
| -------- | -------- | -------- |
| 无       | 无       | 无       |

参数:

| 参数名称 | 参数类型 | 是否必填 |
| -------- | -------- | -------- |
| username | String   | 是       |
| password | String   | 是       |
| type     | Int      | 是       |

返回值:

```
{
    "code":200,
    "meg":"注册成功"
}
```

## 文字描述

 同步的自动化测试在高并发、多任务的情况下可能会消耗一部分时间,而使用异步的方式自动化测试能更好的提高效率。

 ## 接口代码实例

 ```
import unittest

from unittest.async_case import IsolatedAsyncioTestCase

from HTMLTestRunner import HTMLTestRunner

import requests

 # 声明异步方法
async def get():

    res = requests.post("http://localhost:8000/userinfo/",data={"username":"Admin12","password":"zhang123","type":1})

    res=res.json()0

    return res["meg"]




异步测试用例
class Test(IsolatedAsyncioTestCase):

    async def setUp(self):

        pass

    async def test_len(self):

        res = await get()

        self.assertEqual(res,"注册成功")

    async def tearDown(self) -> None:
        
        pass
    
if __name__=='__main__':

    # 构造测试集
    suite = unittest.TestSuite()

    suite.addTest(Test("register"))

    #使用testrunner生成测试报告
    runner = HTMLTestRunner(log=True,output="report",title="test report",report_name="report",open_in_browser=True
    ,description="注册接口测试")

    runner.run(suite)
 ```

 ## 10.2.4 测试报告★★★★★

 ![](/Users/hanxiaobai/Downloads/python/实训一/讲义新/day11/广告竞价平台课件/images/report.png)

