#什么是队列？
队列是一种特殊的线性表，特殊之处在于它只允许在表的前端（front）进行删除操作，而在表的后端（rear）进行插入操作，和栈一样，队列是一种操作受限制的线性表。进行插入操作的端称为队尾，进行删除操作的端称为队头。

ack应答机制

#什么是消息队列？
消息队列，用于存储还未被消费者消费的消息；
常见的6种RabbitMQ队列：
![](Images/111.png)

1、	简单队列模式：最简单的工作队列，其中一个消息生产者，一个消息消费者，一个队列。也称为点对点模式
![](Images/12.png)

2、	竞争消费者模式：一个消息生产者，一个交换器，一个消息队列，多个消费者。同样也称为点对点模式
![](Images/13.png)
3、	发布/订阅模式：无选择接收消息，一个消息生产者，一个交换器，多个消息队列，多个消费者。称为发布/订阅模式
 ![](Images/14.png)
4、	Routing模式：在发布/订阅模式的基础上，有选择的接收消息，也就是通过routing进行匹配条件是否满足接收消息。
 ![](Images/15.png)
5、	主题模式：同样是在发布/订阅模式的基础上，根据主题匹配进行筛选是否接收消息，比第四类更灵活。
 ![](Images/16.png)
6、	RPC模式：与上面其他5种所不同之处，类模式是拥有请求/回复的。也就是有响应的，上面5种都没有。
 ![](Images/17.png)
#RabbitMQ存储和队列结构

存储原理

首先确认一个点，持久化和非持久化的消息都会落地磁盘，区别在于持久化的消息一定会写入磁盘(并且如果可以在内存中也会有一份)，而非持久化的消息只有在内存吃紧的时候落地磁盘。两种类型消息的落盘都是在RabbitMQ的持久层中完成的。

RabbitMQ的持久层只是一个逻辑上的概念，实际包含两个部分：

•	队列索引(rabbit_queue_index)：负责维护队列中落盘消息的信息，包括消息的存储地点、是否己被交付给消费者、是否己被消费者ack等。 每个队列都有与之对应的一个rabbit_queue_index

•	消息存储(rabbit_msg_store)：以键值对的形式存储消息，它被所有vhost中的队列共享，在每个vhost中有且只有一个。rabbit_msg_store具体还可以分为 msg_store_persistent和msg_store_transient，msg_store_persistent负责持久化消息的持久化，重启后消息不会丢失；msg_store_transient负责 非持久化消息的持久化，重启后消息会丢失。

消息(包括消息体、属性和headers)可以直接存储在rabbit_queue_index中，也可以被保存在rabbit_msg_store中。

最佳的配备方式是较小的消息存储在rabbit_queue_index中而较大的信息则存储在rabbit_msg_store中。消息大小的参数可以通过queue_index_embed_mgs_below来配置，默认大小4096，单位B。
rabbit_queue_index中以顺序的段文件来开始存储，后缀为".idx"，每个段文件中包含固定的SEGMENT_ENTRY_COUNT条记录，SEGMENT_ENTRY_COUNT默认值是16384。
经过rabbit_msg_store处理的所有消息都会以追加的方式写入到文件中，当一个文件的大小超过指定的限制(filesizelimit)后，关闭这个文件再创建一个新的文件以供新的消息写入。文件名(文件后缀是".rdq")从0开始进行累加，因此文件名最小的文件也是最老的文件。在进行消息的存储时，RabbitMQ会在ETS(Erlang Term Storage)表中记录消息在文件中的位置映射(Index)和文件的相关信息(FileSummary)。
在读取消息的时候，先根据消息的ID(msg id)找到对应存储的文件，如果文件存在并且未被锁住，则直接打开文件，从指定位置读取消息的内容。如果文件不存在或者被锁住了，则发送请求由rabbit_msg_store进行处理。
消息删除是只是删除ETS表中该消息的相关信息，同时更新消息对应的存储文件的相关信息。执行消息删除操作时，并不立即对文件中的消息进行删除，也就是说消息依然在文件中，仅仅是被标识为垃圾数据而已。一个文件中都是垃圾数据时可以将这个文件删除。当检测到前后两个文件中的有效数据可以合并在一个文件中，并且所有的垃圾数据的大小和所有文件(至少有3个文件存在的情况下)的数据大小的比值超过设置的阀值GARBAGE FRACTION(默认值为0.5)时才会触发垃圾回收将两个文件合并。

#队列结构
通常队列由rabbit_amqpqueue_process和backing_queue两部分组成：
•	rabbit_amqpqueue_process：负责协议相关的消息处理(即接收生产者发布的消息、向消费者交付消息、处理消息的确认(包括生产端的confirm和消费端的ack))等
•	backing_queue：消息存储的具体形式和引擎，并向rabbit_amqpqueue_process提供接口以供调用
如果消息发送的队列是空的且队列有消费者，该消息不会经过该队列直接发往消费者，如果无法直接被消费，则需要将消息暂存入队列，以便重新投递。消息在存入队列后，主要有以下几种状态：
•	alpha：消息内容(包括消息体、属性和headers)和消息索引都存在内存中
•	beta：消息内容保存在磁盘中，消息索引都存在内存中
•	gamma：消息内容保存在磁盘中，消息索引在磁盘和内存中都存在
•	delta：消息内容和消息索引都在磁盘中
持久化的消息，消息内容和消息索引必须都保存在磁盘中，才会处于上面状态中的一种，gamma状态只有持久化的消息才有这种状态。
对于没有设置优先级和镜像的队列来说，backing_queue的默认实现是rabbit_variable_queue，其内部通过5个子队列来体现消息的各个状态：
•	Q1：只包含alpha状态的消息
•	Q2：包含beta和gamma的消息
•	Delta：包含delta的消息
•	Q3：包含beta和gamma的消息
•	Q4：只包含alpha状态的消息
消息的状态一般变更方向是Q1->Q2->Delta->Q3->Q4，大体是从内存到磁盘然后再到内存中。
 ![](Images/18.png)
#消费者消费消息也会引起消息状态的转换。

1.	消费者消费时先从Q4获取消息，如果获取成功则返回。

2.	如果Q4为空，则从Q3中获取消息，首先判断Q3是否为空，如果为空返回队列为空，即此时队列中无消息

3.	如果Q3不为空，取出Q3的消息，然后判断Q3和Delta中的长度，如果都为空，那么Q2、Delta、Q3、Q4都为空，直接将Q1中的消息转移至Q4，下次直接从Q4中读取消息

4.	如果Q3为空，Delta不为空，则将Delta中的消息转移至Q3中，下次直接从Q3中读取。

5.	在将消息从Delta转移至Q3的过程中，是按照索引分段读取，首先读取某一段，然后判断读取的消息个数和Delta消息的个数，如果相等，判定Delta已无消息，直接将读取 Q2和读取到消息一并放入Q3，如果不相等，仅将此次读取的消息转移到Q3。
   通常在负载正常时，如果消息被消费的速度不小于接收新消息的速度，对于不需要保证可靠不丢失的消息来说，极有可能只会处于alpha状态。对于durable属性设置为true的消息，它一定会进入gamma状态，并且在开启publisher confirm机制时，只有到了gamma状态时才会确认该消息己被接收，若消息消费速度足够快、内存也充足，这些消息也不会继续走到下一个状态。
   惰性队列
   惰性队列会将接收到的消息直接存入文件系统中，而不管是持久化的或者是非持久化的，这样可以减少了内存的消耗，但是会增加I/0的使用，如果消息是持久化的，那么这样的I/0操作不可避免，惰性队列和持久化的消息可谓是"最佳拍档"。
   队列具备两种模式：default和lazy。在队列声明的时候可以通过x-queue-mode参数来设置队列的模式，取值为default和lazy。对应的 Policy设置方式为:
   rabbitmqctl set_policy lazy "^myQueue$" '{"queue-mode":"lazy"}' --apply-to queue

Redis也可用作消息队列。
它的列表类型天生支持用作消息队列。
![](Images/19.png)

三、redis做消息队列及问题: 

redis的list类型天生支持用作消息队列。可以由生产消费模型,发布订阅模式实现消息队列.由于redis的list是使用双向链表实现的，保存了头尾节点，所以在列表头尾两边插取元素都是
非常快的。所以可以直接使用redis的list实现消息队列，只需简单的两个指令lpush和rpop或者rpush和lpop。 
![](Images/20.png)
![](Images/21.png)

1.	六、redis 和  rabbitmq  做消息队列 他两之间的区别?

可靠消费

Redis：没有相应的机制保证消息的消费，当消费者消费失败的时候，消息体丢失，需要手动处理
RabbitMQ：具有消息消费确认，即使消费者消费失败，也会自动使消息体返回原队列，同时可全程持久化，保证消息体被正确消费

可靠发布

Reids：不提供，需自行实现
RabbitMQ：具有发布确认功能，保证消息被发布到服务器

高可用

Redis：采用主从模式，读写分离，但是故障转移还没有非常完善的官方解决方案
RabbitMQ：集群采用磁盘、内存节点，任意单点故障都不会影响整个队列的操作

持久化

Redis：将整个Redis实例持久化到磁盘
RabbitMQ：队列，消息，都可以选择是否持久化

消费者负载均衡

Redis：不提供，需自行实现
RabbitMQ：根据消费者情况，进行消息的均衡分发

队列监控

Redis：不提供，需自行实现
RabbitMQ：后台可以监控某个队列的所有信息，（内存，磁盘，消费者，生产者，速率等）

流量控制

Redis：不提供，需自行实现
RabbitMQ：服务器过载的情况，对生产者速率会进行限制，保证服务可靠性

出入队性能

对于RabbitMQ和Redis的入队和出队操作，各执行100万次，每10万次记录一次执行时间。
测试数据分为128Bytes、512Bytes、1K和10K四个不同大小的数据。
![](Images/22.png)

应用场景分析

Redis：轻量级，高并发，延迟敏感
即时数据分析、秒杀计数器、缓存等

RabbitMQ：重量级，高并发，异步
批量数据异步处理、并行任务串行化，高负载任务的负载均衡等

Rabbitmq怎么保证可靠性?
目前来说，现在有两种方案实施： 

Rabbitmq docker部署

~~~
步骤 1: 安装 Docker
确保你的机器上已经安装了Docker。如果还没有安装，可以访问Docker官网下载并安装适用于你的操作系统的版本。

步骤 2: 拉取 RabbitMQ 镜像
打开命令行工具，运行以下命令来拉取官方的RabbitMQ镜像（基于管理插件版本）：


docker pull rabbitmq:3-management
这会将包含管理界面的RabbitMQ最新版本镜像下载到你的本地。

步骤 3: 运行 RabbitMQ 容器
使用以下命令启动一个RabbitMQ容器，并将容器的端口映射到主机的端口：


docker run -d --name some-rabbit -p 5672:5672 -p 15672:15672 rabbitmq:3-management
这里 -d 表示在后台运行容器；--name some-rabbit 给容器命名；-p 参数用于端口映射，例如 5672:5672 和 15672:15672 分别映射了AMQP协议和管理控制台的默认端口。

访问管理界面
一旦容器运行起来，你可以通过浏览器访问http://localhost:15672来打开RabbitMQ的管理控制台，默认的用户名和密码都是guest。

docker run -d --name some-rabbit 
-v /mnt/data/rabbitmq:/data \ 
-p 5672:5672 -p 15672:15672 rabbitmq:3-management

-d：后台运行容器。
--name some-rabbit：给容器命名。
-v /mnt/data/rabbitmq:/data：将宿主机上的/mnt/data/redis目录挂载到容器内的/data目录。
-p 5672:5672：映射容器内部的6379端口到宿主机的6379端口。
rabbitmq:3-management：使用最新的Redis镜像。

~~~

pika实现

~~~python
当然，下面是使用pika库操作RabbitMQ的基本案例代码，包括一个生产者和一个消费者。这里假设RabbitMQ的地址为localhost，并且使用的用户名和密码均为guest。

生产者 (producer.py)
生产者用来发送消息到RabbitMQ。

import pika
def send_order_to_rabbitmq(orders):
    credentials = pika.PlainCredentials('guest', 'guest')
    parameters = pika.ConnectionParameters('39.105.220.219', 15672, '/', credentials)
    
    try:
        connection = pika.BlockingConnection(parameters)
        channel = connection.channel()
        
        # 声明队列，如果队列还不存在的话
        channel.queue_declare(queue='orders')
        str_orders = json.dumps(orders)
        # 发送订单ID到队列
        channel.basic_publish(
            exchange='',
            routing_key='orders',
            body=str_orders,
            properties=pika.BasicProperties(
                delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE  # 持久化消息
            )
        )
        
        connection.close()
    except Exception as e:
        print(f"Failed to publish message: {e}")
        
        
send_order_to_rabbitmq('212')

消费者 (consumer.py)
消费者用来接收队列中的消息。

# consumer.py
import pika

def callback(ch, method, properties, body):
    orders = str(body)
    print(f"Received order ID: {orders}")
    # 处理订单业务逻辑，例如发送邮件通知、打印订单等...

def start_consumer():
    credentials = pika.PlainCredentials('guest', 'guest')
    parameters = pika.ConnectionParameters('localhost', 5672, '/', credentials)
    
    connection = pika.BlockingConnection(parameters)
    channel = connection.channel()
    
    channel.queue_declare(queue='orders')
    
    channel.basic_consume(queue='orders', on_message_callback=callback, auto_ack=True)
    
    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()
    
start_consumer()

~~~

订单模块重构

~~~
生成总诊订单
data = {"order_no":'123','title':'234'}
send_order_to_rabbitmq(data)
return Response({"code":200})
~~~



 

### 02  redis PUB/SUB,订阅/发布模式

简述:
不适合做消息存储,擅长广播通信,即时通信,即时反馈的业务
命令:
SUBSCRIBE     用于订阅频道
PUBLISH       向频道发送消息
UNSUBSCRIBE       取消订阅
优点:

1.  广播模式,一个消息可以发布到多个消费者
2.  消费者可以订阅多个频道,接收多类消息
3.  消息即时发送,不用等待消费者读取
    缺点:
4.  如果发布消息是客户端不在线,消息就会丢失
5.  如果客户端出现积压,到一定成度,会被强制断开,导致消息丢失

发布脚本

~~~python
import redis
import time

def publish_message(channel, message):
    r = redis.Redis(host='localhost', port=6379, db=0)
    r.publish(channel, message)
    print(f"Published message: {message} to channel: {channel}")

if __name__ == "__main__":
    channel = 'chat'
    while True:
        message = input("Enter your message: ")
        if message.lower() == 'exit':
            break
        publish_message(channel, message)
~~~

 订阅

~~~python
import redis

def subscribe_to_channel(channel):
    r = redis.Redis(host='localhost', port=6379, db=0)
    pubsub = r.pubsub()
    pubsub.subscribe(channel)
    
    while True:
        for item in pubsub.listen():
            if item['type'] == 'message':
                print(f"Received message: {item['data']} from channel: {channel}")

if __name__ == "__main__":
    channel = 'chat'
    subscribe_to_channel(channel)
~~~









