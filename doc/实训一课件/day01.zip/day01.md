### 1.项目中的角色

https://www.axureshop.com/ys/2173349

<img src="images/21.png">

### 2.功能模块

业务：

注册、登录、三方登录（微博登录）、实名认证（百度api，qps限制）、充值（支付宝，回调接口验签，事务，支付成功回调失败，半小时没支付订单的处理）、发布视频（分表、大文件分片上传）、关注、评论（mongo）、聊天（websocket）、搜索（es）、首页推荐功能（协同过滤算法）

管理：

手机号登录、权限管理(rbac,位运算)、用户管理、内容管理（分类管理、内容管理、内容审核）、营销管理（广告位、礼物）、推广（echarts）、财务管理（查看订单、统计功能）

Docker部署mysql主重

部署nginx

### 3.数据库字典

用户表（users）

<table>
  <tr><td>字段名</td><td>字段类型</td><td>中文名</td><td>描述</td></tr>
  <tr><td>id</td><td>int</td><td>ID</td><td>主键自增</td></tr>
  <tr><td>mobile</td><td>char(11)</td><td>手机号</td><td>唯一</td></tr>
  <tr><td>types</td><td>char(11)</td><td>手机号</td><td>唯一</td></tr>
</table>



作业：

1.项目需求画er图

2.设计数据库字典





