A简历

短视频、健身、医美、社交平台、大屏可视化、金融、在线教育平台（腾讯课堂，51talk）、电信、银行、CRM、ERP

~~~
个人信息：
姓名    工作年限
邮箱    手机号
求职意向    学历


学历
2013-2018   北京大学    计算机科学与技术

技能列表（至少8条）
1.熟练使用python中的django、flask、tornado框架
2.对异步编程有深入的理解,asyncio、celery


工作经历

2021-8——————2023-9  上海科技公司    python工程师
1.部门间的沟通协调
2.核心功能模块的开发
3.从0参与项目，需求分析、数据库设计
4.技术分享会
5.客户现场安装部署项目
7.项目的培训
8.参与“”专例项目的研发

2019-8——————2021-7  上海科技公司（外包）    python工程师

2019-8——————2021-7  上海科技公司    python工程师



项目经验（4-5个项目）
小红书（至少8条）
小红书是年轻信人的生活方式。。。。。。。。核心模块有用户管理、发布管理、充值管理

技术栈： django+vant+redis+mongdb+分治算法+celery+分表+雪花算法+支付宝+mysql
责任描述：
     1.jwt用户认证模块，实现接口安全认证
     2.工厂模块对三方登录的封装
     。。。
     
业绩：
   用户量从10半年时间内增加到100万
   部署100家企业
   
   
小红书后台管理（至少8条）
核心模块。。。。
责任描述：
  1.rbac权限管理
  2.推广模块 echarts+mysql分组
  
  
  
小红书推荐系统

     
  

~~~

个性签名

~~~

~~~





### 协同过滤算法1.协同过滤算法

~~~
1.基于用户的
   （1）统计用户群体，相当于给用户分类
   （2）当A购买一个物品时，通过这个物品查询和他一类的这些人是否买过，如果没有就推荐
   
2.基于物品的
    经常看哪类，关注哪类，推荐哪类
~~~

### 2.实现流程

~~~
首页展示视频
1.发布表中添加is_show_index字段，默认为0不在首页展示
2.管理员在后台更新展示状态为展示（后台管理系统中分页展示所有视频-》管理员点击首页展示-》更新数据库中首页展示字段）-》把首页展示的写入首页展示表


1.用户登录成功后-》首页展示视频-》点击查看写入浏览记录表（id,用户id,视频id,总次数）

新建一张浏览记录表
id userid  videoid  number  score
1   1       1         10     2
2   1       5          5     1
5   4       5         7
3   2       1         7
4   3       8         2


获取推荐视频
1.查询当前用户观看过的视频
select * from views where userid=1
list=[1,5,8]
2.查询视频列表被谁看过
users = select * rom views where videoid in (1,5,8)
userlist={"4":7,'2':7}
3.计算和我相似度最高的人
4,2
4.查询这几人看的视频列表 list1=[1,2,4,5]  查询我看到过的 list2=[1,2,3]

~~~

~~~python
def recommend_movies(request):
    # 获取当前用户的所有购买的商品
    user_ratings = UserViews.objects.filter(userid=1).values('videoid')
    strs = ""
    for i in user_ratings:
       strs=strs+str(i)+","
     strs = strs.split(0,-2)
     userlist = UserViews.objects.filter(videoid__in(strs)).values("userid",'count')
     dict = {}
     for i in userlist:
        dict={i[0]:i[1]}
        
     #相似度最高的用户列表
     similar_users = sorted(dict, key=lambda x: x[1])[:10]
      
     
      videolist = UserViews.objects.filter(userid__in(similar_users)).all()
      
      
      
    # 计算当前用户与其他用户的相似度
    similarity_scores = {'2':{'score':1,'count':9}}
    #遍历此用户订单
    for rating in user_ratings:
        #查询和此用户购买商品相同的人
        for r in OrdersDetils.objects.filter(vedioid=rating.vedioid).exclude(userid=1):
            if r.userid not in similarity_scores:
                similarity_scores[r.userid] = {'score': 0, 'count': 0}
            similarity_scores[r.userid]['score'] += abs(r.number - rating.number)
            similarity_scores[r.userid]['count'] += 1
    for user, score_count in similarity_scores.items():
        similarity_scores[user]['score'] = score_count['score'] / score_count['count'] if score_count['count'] > 0 else 0

    # 按相似度排序，选出与当前用户相似度最高的前 n 个用户
    similar_users = sorted(similarity_scores.items(), key=lambda x: x[1]['score'])[:10]

    # 找出这些用户买过但是我没买过的商品进行推荐
    recommended_movies = []
    for user, score_count in similar_users:
        for rating in OrderDetails.objects.filter(userid=user):
            if not OrderDetails.objects.filter(vedioid=rating.vedioid, userid=1).exists():
                vedios = Publish0.objects.filter(id=rating.vedioid).first()
                recommended_movies.append({"vedioid":rating.vedioid,'tcount':rating.tcount,'name':vedios.title})
                

    # 按平均评分排序，选出前 n 个商品作为推荐结果
    recommended_movies = sorted(recommended_movies, key=lambda x: x['tcount'], reverse=True)[:10]

    return JsonResponse({"code":200,'list':recommended_movies})
~~~



~~~python
def recommend_movies(request):
    # 获取当前用户的所有购买的商品
    user_ratings = OrdersDetils.objects.filter(userid=1)

    # 计算当前用户与其他用户的相似度
    similarity_scores = {'2':{'score':1,'count':9}}
    #遍历此用户订单
    for rating in user_ratings:
        #查询和此用户购买商品相同的人
        for r in OrdersDetils.objects.filter(vedioid=rating.vedioid).exclude(userid=1):
            if r.userid not in similarity_scores:
                similarity_scores[r.userid] = {'score': 0, 'count': 0}
            similarity_scores[r.userid]['score'] += abs(r.number - rating.number)
            similarity_scores[r.userid]['count'] += 1
    for user, score_count in similarity_scores.items():
        similarity_scores[user]['score'] = score_count['score'] / score_count['count'] if score_count['count'] > 0 else 0

    # 按相似度排序，选出与当前用户相似度最高的前 n 个用户
    similar_users = sorted(similarity_scores.items(), key=lambda x: x[1]['score'])[:10]

    # 找出这些用户买过但是我没买过的商品进行推荐
    recommended_movies = []
    for user, score_count in similar_users:
        for rating in OrderDetails.objects.filter(userid=user):
            if not OrderDetails.objects.filter(vedioid=rating.vedioid, userid=1).exists():
                vedios = Publish0.objects.filter(id=rating.vedioid).first()
                recommended_movies.append({"vedioid":rating.vedioid,'tcount':rating.tcount,'name':vedios.title})
                

    # 按平均评分排序，选出前 n 个商品作为推荐结果
    recommended_movies = sorted(recommended_movies, key=lambda x: x['tcount'], reverse=True)[:10]

    return JsonResponse({"code":200,'list':recommended_movies})
~~~

实现

~~~
1.查询浏览记录表，大于3条，采用协同过滤算法中的基于用户的推荐获取视频列表
2.如果不存在
select * from publish0 limit 0,2 order by add_time desc union all select * from publish1 limit 0,2 order by add_time desc union select * from publish2 limit 0,2 order by add_time desc;


视频1
视频2
视频3

3.点击视频1，dialog弹出框，播放视频。写入到浏览记录表


~~~

